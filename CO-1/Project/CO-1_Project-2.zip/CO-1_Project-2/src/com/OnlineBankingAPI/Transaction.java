package com.OnlineBankingAPI;

public interface Transaction {
    void execute();
}
