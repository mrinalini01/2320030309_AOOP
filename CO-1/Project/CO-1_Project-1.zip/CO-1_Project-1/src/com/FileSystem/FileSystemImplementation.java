package com.FileSystem;

public interface FileSystemImplementation {
	void addElement(FileSystemElement element);
    void removeElement(FileSystemElement element);
    void displayElement(String name);
}
